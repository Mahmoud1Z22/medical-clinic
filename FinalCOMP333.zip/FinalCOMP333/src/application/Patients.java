package application;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Patients {
	private int pId;
	private String pName;
	private Date date;
	private String address;
	private String chekups;
	private String phone;
	
	private Date insurance;
	public Patients(int pId, String pName, Date date, String address, String chekups,String phone,Date insurance) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.date = date;
		this.address = address;
		this.chekups = chekups;
		this.phone=phone;
		this.insurance=insurance;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public Date getDate() {
		return date;
	}
	
	public String getDateOFBirth() {
		SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
		String dateFormatted = fmt.format(date);
		return dateFormatted;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getChekups() {
		return chekups;
	}
	public void setChekups(String chekups) {
		this.chekups = chekups;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getInsurance() {
		return insurance;
	}
	
	public String getINSOFBirth() {
		SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
		String dateFormatted = fmt.format(insurance);
		return dateFormatted;
	}
	
	public void setInsurance(Date insurance) {
		this.insurance = insurance;
	}
	@Override
	public String toString() {
		return "Patients [pId=" + pId + ", pName=" + pName + ", date=" + date + ", address=" + address + ", chekups="
				+ chekups + ", phone=" + phone + ", insurance=" + insurance + "]";
	}
	

}
