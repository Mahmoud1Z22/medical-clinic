package application;

import java.util.Date;

public class Doctors2PatientsTreats {
	private int dId;
	private int pId;
	private Date tDate;
	
	public Doctors2PatientsTreats(int dId, int pId, Date tDate) {
		super();
		this.dId = dId;
		this.pId = pId;
		this.tDate = tDate;
	}
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	
	public Date gettDate() {
		return tDate;
	}
	public void settDate(Date tDate) {
		this.tDate = tDate;
	}
	@Override
	public String toString() {
		return "Doctors2PatientsTreats [dId=" + dId + ", pId=" + pId + "]";
	}

}
