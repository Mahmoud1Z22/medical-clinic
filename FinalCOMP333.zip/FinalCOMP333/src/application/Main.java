package application;

import java.sql.Connection;
import java.util.ArrayList;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

//import com.mysql.fabric.xmlrpc.base.Value;

import javafx.application.Application;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

@SuppressWarnings("unchecked")
public class Main extends Application {
	String[][] login = { { "Mahmoud", "mahmoud" }, { "Abed", "abed" }, { "Mohammad", "mohammad" } };
	Scene welcomeSceneEng;
	ArrayList<Doc2Pa2Drug_Discribe> doc2Pa2Drug_Discribe = new ArrayList<>();
	ArrayList<Doctors> doctors = new ArrayList<>();
	ArrayList<Doctors2PatientsTreats> doctors2PatientsTreats = new ArrayList<>();
	ArrayList<Drugs> drugs = new ArrayList<>();
	ArrayList<Manager_manage> manager_mgr = new ArrayList<>();
	ArrayList<Manager_Phones> mgr_Phone = new ArrayList<>();
	ArrayList<Medical_Lab_EMP2RES> medical_Lab_EMP = new ArrayList<>();
	ArrayList<Patients> patients = new ArrayList<>();
	ArrayList<Tests> tests = new ArrayList<>();

	private static Connection con;
	static int ID;
	private Alert error = new Alert(AlertType.ERROR);
	private Alert success = new Alert(AlertType.INFORMATION);
	String userLogin;

	@Override
	public void start(Stage primaryStage) {
		try {
			connectDataBase(primaryStage);
			primaryStage.setResizable(false);
			primaryStage.setTitle("Medical Center");
			primaryStage.getIcons().add(new Image(
					"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\icon.png"));

		} catch (Exception e) {
			error.setContentText(e.getMessage());
			error.show();
		}
	}

	private void connectDataBase(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(950);
		pane.getChildren().add(background);

		Label welcome = new Label("				");
		welcome.setStyle("-fx-font-size: 50;");
		welcome.setTextFill(Color.web("white"));

		VBox v1 = new VBox(40, welcome);
		v1.setAlignment(Pos.CENTER);

		Label user = new Label("DataBase Name:");
		user.setPadding(new Insets(7));
		Label pass = new Label("PASSWORD :");
		pass.setPadding(new Insets(7));
		TextField usert = new TextField();
		PasswordField passt = new PasswordField();
		IconedTextFieled(user, usert);
		IconedTextFieled(pass, passt);

		HBox h1 = new HBox(user, usert);
		h1.setAlignment(Pos.CENTER);
		HBox h2 = new HBox(pass, passt);
		h2.setAlignment(Pos.CENTER);

		Button logIN = new Button("lOG IN");
		logIN.setEffect(new DropShadow());

		icons(logIN);
		butoonEffect(logIN);

		Label wrongPass = new Label();

		VBox v = new VBox(30, wrongPass, h1, h2, logIN);
		v.setAlignment(Pos.CENTER);

//		HBox hh = new HBox(200, v1, v);
		HBox hh = new HBox(200,  v);
		hh.setAlignment(Pos.CENTER);
		pane.setCenter(hh);
		logIN.setOnAction(e -> {
			try {
				con = DriverManager.getConnection(
						"jdbc:mysql://127.0.0.1:3306/" + usert.getText() + "?autoReconnect=true&useSSL=false", "root",
						passt.getText());
				loginPage(primaryStage);

			} catch (SQLException ee) {
				error.setContentText("Can't connect to database");
				error.show();
			}
		});

		pane.setCenter(hh);

		welcomeSceneEng = new Scene(pane, 1535, 800);
		primaryStage.setScene(welcomeSceneEng);
		primaryStage.show();

	}

	private ResultSet appyQueryOnDataBase(String string) {

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(string);
			return rs;
		} catch (SQLException e) {
			error.setContentText(string);
			error.show();
		}

		return null;

	}

	private boolean applyOnDataBase(String string) throws SQLException {

		try {
			Statement stmt = con.createStatement();
			boolean rs = stmt.execute(string);
			return rs;
		} catch (SQLException e) {
			error.setContentText(string);
			error.show();
		}
		return false;

	}

	public static void main(String[] args) {
		launch(args);
	}

	private void loginPage(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(950);
		pane.getChildren().add(background);

		Label welcome = new Label("				");
		welcome.setStyle("-fx-font-size: 50;");
		welcome.setTextFill(Color.web("white"));

		VBox v1 = new VBox(40, welcome);
		v1.setAlignment(Pos.CENTER);

		Label user = new Label("USER NAME");
		user.setPadding(new Insets(7));
		Label pass = new Label("PASSWORD ");
		pass.setPadding(new Insets(7));
		TextField usert = new TextField();
		PasswordField passt = new PasswordField();
		IconedTextFieled(user, usert);
		IconedTextFieled(pass, passt);

		HBox h1 = new HBox(user, usert);
		h1.setAlignment(Pos.CENTER);
		HBox h2 = new HBox(pass, passt);
		h2.setAlignment(Pos.CENTER);

		Button logIN = new Button("lOG IN");
		logIN.setEffect(new DropShadow());

		icons(logIN);
		butoonEffect(logIN);

		Label wrongPass = new Label();

		VBox v = new VBox(30, wrongPass, h1, h2, logIN);
		v.setAlignment(Pos.CENTER);

		HBox hh = new HBox(200, v1, v);

		hh.setAlignment(Pos.CENTER);
		pane.setCenter(hh);
		logIN.setOnAction(e -> {
			boolean flag = false;
			for (int j = 0; j < login.length; j++) {
				if (usert.getText().equals(login[j][0]) && passt.getText().equals(login[j][1])) {
					flag = true;
					userLogin = usert.getText();
					Action(primaryStage);
					wrongPass.setText("");
					usert.clear();
					passt.clear();
				}
			}
			if (!flag) {
				wrongPass.setText("! Wrong Username or Password !");
				wrongPass.setStyle("-fx-font-size: 15;\n" + "-fx-text-fill: white;");
				usert.clear();
				passt.clear();
			}
		});

		pane.setCenter(hh);

		welcomeSceneEng = new Scene(pane, 1535, 800);
		primaryStage.setScene(welcomeSceneEng);
		primaryStage.show();
	}

	private void Action(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(950);
		pane.getChildren().add(background);

//		reprots
		TableView<Doctors> docTable = tableDoctors();
		TableView<Patients> patientsTable = tablePatients();
		TableView<Medical_Lab_EMP2RES> mleTable = tableMLE();
//		TableView<NonRentCar> nonRentTable = tableNonRentCar();
//		reports

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\DOC.jpg"));
		a.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		a.setFitHeight(60);
		a.setFitWidth(70);
		Label l = new Label("   Doctors   ");
		l.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l.setFont(new Font("Times New Roman", 15));

		Label l2 = new Label("0");
		l2.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l2.setFont(new Font("Times New Roman", 15));

		VBox h = new VBox(15, l, a, l2);
		h.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		h.setPadding(new Insets(10));
		h.setAlignment(Pos.CENTER);
		h.setPrefSize(150, 150);
		icons(h);
		butoonEffect(h);
		ResultSet rs = appyQueryOnDataBase("SELECT count(*) FROM Doctors;");
		try {
			rs.next();
			l2.setText(rs.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		
		///////////////////////////
		ImageView aa = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\money.png"));
		aa.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		aa.setFitHeight(60);
		aa.setFitWidth(70);
		Label ll = new Label("Doctors Pays");
		ll.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		ll.setFont(new Font("Times New Roman", 15));

		Label ll2 = new Label("0");
		ll2.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		ll2.setFont(new Font("Times New Roman", 15));

		VBox hh = new VBox(15, ll, aa, ll2);
		hh.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		hh.setPadding(new Insets(10));
		hh.setAlignment(Pos.CENTER);
		hh.setPrefSize(150, 150);
		icons(hh);
		butoonEffect(hh);
		ResultSet rss = appyQueryOnDataBase("SELECT SUM(d.salary) FROM Doctors d;");
		try {
			rss.next();
			ll2.setText(rss.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		
		
		
		
		////////////////////////////////////

		ImageView a2 = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\Lab.png"));
		a2.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		a2.setFitHeight(60);
		a2.setFitWidth(70);
		Label l3 = new Label("Lab Worker");
		l3.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l3.setFont(new Font("Times New Roman", 15));

		Label l4 = new Label("0");
		l4.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l4.setFont(new Font("Times New Roman", 15));

		ResultSet res = appyQueryOnDataBase("SELECT count(*) FROM Medical_Lab_EMP2RES;");
		try {
			res.next();
			if (res.getString(1) != null)
				l4.setText(res.getString(1));
			else
				l4.setText("0");

		} catch (SQLException e2) {
			error.setContentText(e2.getMessage());
			error.show();
		}

//		try {
//			res.next();
//			l4.setText(res.getString(1));
//		} catch (SQLException e1) {
//			error.setContentText(e1.getMessage());
//			error.show();
//		}

		VBox h2 = new VBox(15, l3, a2, l4);
		h2.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		h2.setPadding(new Insets(10));
		h2.setAlignment(Pos.CENTER);
		h2.setPrefSize(150, 150);
		icons(h2);
		butoonEffect(h2);
		
		/////////////////////////
		
		ImageView aa2 = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\money.png"));
		aa2.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		aa2.setFitHeight(60);
		aa2.setFitWidth(70);
		Label ll3 = new Label("Lab Worker pays");
		ll3.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		ll3.setFont(new Font("Times New Roman", 15));

		Label ll4 = new Label("0");
		ll4.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		ll4.setFont(new Font("Times New Roman", 15));

		ResultSet rres = appyQueryOnDataBase("SELECT SUM(m.salary) FROM Medical_Lab_EMP2RES m;");
		try {
			rres.next();
			if (rres.getString(1) != null)
				ll4.setText(rres.getString(1));
			else
				ll4.setText("0");

		} catch (SQLException e2) {
			error.setContentText(e2.getMessage());
			error.show();
		}

		VBox h22 = new VBox(15, ll3, aa2, ll4);
		h22.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		h22.setPadding(new Insets(10));
		h22.setAlignment(Pos.CENTER);
		h22.setPrefSize(150, 150);
		icons(h22);
		butoonEffect(h22);

		/////////////////////////////////////////////////////////
		// patient
		ImageView a3 = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\patient.png"));
		a3.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		a3.setFitHeight(70);
		a3.setFitWidth(70);
		Label l5 = new Label("  Patients ");
		l5.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l5.setFont(new Font("Times New Roman", 15));

		Label l6 = new Label("0");
		l6.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		l6.setFont(new Font("Times New Roman", 15));

		ResultSet re = appyQueryOnDataBase("SELECT count(*) FROM Patients;");
		try {
			re.next();
			if (re.getString(1) != null)
				l6.setText(re.getString(1));
			else
				l6.setText("0");

		} catch (SQLException e2) {
			error.setContentText(e2.getMessage());
			error.show();
		}

		VBox h3 = new VBox(15, l5, a3, l6);
		h3.setEffect(new DropShadow(5, Color.web("#d8d9e0")));
		h3.setPadding(new Insets(10));
		h3.setAlignment(Pos.CENTER);
		h3.setPrefSize(150, 150);
		icons(h3);
		butoonEffect(h3);

		HBox h4 = new HBox(35, h, hh, h2, h22,  h3);
		h4.setAlignment(Pos.CENTER);
		h4.setPadding(new Insets(10));
		h4.setMaxSize(900, 500);
		BorderPane pane2 = new BorderPane();

		VBox v = new VBox(20, h4);
		v.setAlignment(Pos.CENTER);
		v.setPadding(new Insets(5));
		pane2.setCenter(v);

		h.setOnMouseClicked(e -> {
			ObservableList<Doctors> doctorsList = tableDoctors().getItems();
			docTable.setItems(doctorsList);
			docTable.setVisible(true);
			if (v.getChildren().size() > 1)
				v.getChildren().remove(1);
			v.getChildren().add(docTable);
		});

		h2.setOnMouseClicked(e -> {
			ObservableList<Medical_Lab_EMP2RES> mlwList = tableMLE().getItems();
			mleTable.setItems(mlwList);
			mleTable.setVisible(true);
			if (v.getChildren().size() > 1)
				v.getChildren().remove(1);
			v.getChildren().add(mleTable);
		});

		h3.setOnMouseClicked(e -> {
			ObservableList<Patients> patientsList = tablePatients().getItems();
			patientsTable.setItems(patientsList);
			patientsTable.setVisible(true);
			if (v.getChildren().size() > 1)
				v.getChildren().remove(1);
			v.getChildren().add(patientsTable);
		});
//
//		h5.setOnMouseClicked(e -> {
//			ObservableList<Customer> cus = tableCustomer().getItems();
//			customerTable.setItems(cus);
//			customerTable.setVisible(true);
//			if (v.getChildren().size() > 1)
//				v.getChildren().remove(1);
//			v.getChildren().add(customerTable);
//
//		});

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);

		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	@SuppressWarnings("deprecation")
	private TableView<Patients> tablePatients() {
		TableView<Patients> table = new TableView<Patients>();
		table.setEditable(false);

		TableColumn<Patients, Integer> pId = new TableColumn<Patients, Integer>("ID");
		pId.setMinWidth(200);
		pId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getpId()).asObject());
		pId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> name = new TableColumn<Patients, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getpName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> date = new TableColumn<Patients, String>("Date Of Birth");
		date.setMinWidth(170);
		date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> address = new TableColumn<Patients, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getAddress() + ""));
		address.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> checkups = new TableColumn<Patients, String>("checkups");
		checkups.setMinWidth(170);
		checkups.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getChekups() + ""));
		checkups.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Patients, String> phone = new TableColumn<Patients, String>("Phone Number");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> insurance = new TableColumn<Patients, String>("Expiration of insurance");
		insurance.setMinWidth(170);
		insurance.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getINSOFBirth() + ""));
		insurance.setStyle("-fx-alignment: CENTER;");
		patients.clear();
		ResultSet rs = appyQueryOnDataBase("select * from patients;");
		try {
			if (rs != null)
				while (rs.next()) {
					String[] birthDate = rs.getString(3).split("-");
					String[] inDate = rs.getString(7).split("-");
					patients.add(new Patients(Integer.parseInt(rs.getString(1)), rs.getString(2),
							new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])),
							rs.getString(4), rs.getString(5),rs.getString(6), new Date(Integer.parseInt(inDate[0]) - 1900,
									Integer.parseInt(inDate[1]) - 1, Integer.parseInt(inDate[2]))));

				}

		} catch (NumberFormatException | SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
//
		ObservableList<Patients> data = FXCollections.observableArrayList(patients);

		table.setItems(data);
		table.setMaxWidth(1200);
		table.setMinHeight(180);
		table.getColumns().addAll(pId, name, date, address, checkups, insurance);
		return table;
	}

	@SuppressWarnings("deprecation")
	private TableView<Doctors> tableDoctors() {
		TableView<Doctors> table = new TableView<Doctors>();
		table.setEditable(false);

		TableColumn<Doctors, Integer> dId = new TableColumn<Doctors, Integer>("ID");
		dId.setMinWidth(200);
		dId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getdId()).asObject());
		dId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> name = new TableColumn<Doctors, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, Integer> salary = new TableColumn<Doctors, Integer>("Salary");
		salary.setMinWidth(200);
		salary.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getSalary()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> b_date = new TableColumn<Doctors, String>("Date Of Birth");
		b_date.setMinWidth(170);
		b_date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		b_date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> address = new TableColumn<Doctors, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getAddress() + ""));
		address.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Doctors, String> phone = new TableColumn<Doctors, String>("Phone Number");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> specialty = new TableColumn<Doctors, String>("Specialty");
		specialty.setMinWidth(170);
		specialty.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getSpecialty() + ""));
		specialty.setStyle("-fx-alignment: CENTER;");
		doctors.clear();
		ResultSet rs = appyQueryOnDataBase("SELECT * from Doctors");

		try {
			if (rs != null)
				while (rs.next()) {

					String[] birthDate = rs.getString(4).split("-");
					doctors.add(new Doctors(Integer.parseInt(rs.getString(1)), rs.getString(2),
							Integer.parseInt(rs.getString(3)), new Date(Integer.parseInt(birthDate[0]) - 1900,
									Integer.parseInt(birthDate[1]) - 1, Integer.parseInt(birthDate[2])),
							rs.getString(5), rs.getString(6),rs.getString(7)));

				}

		} catch (NumberFormatException | SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}

		ObservableList<Doctors> data = FXCollections.observableArrayList(doctors);

		table.setItems(data);
		table.setMaxWidth(1250);
		table.setMinHeight(180);
		table.getColumns().addAll(dId, name, salary, b_date, address, specialty);
		return table;
	}

	@SuppressWarnings("deprecation")
	private TableView<Medical_Lab_EMP2RES> tableMLE() {
		TableView<Medical_Lab_EMP2RES> table = new TableView<Medical_Lab_EMP2RES>();
		table.setEditable(false);

		TableColumn<Medical_Lab_EMP2RES, Integer> medical_EMP_ID = new TableColumn<Medical_Lab_EMP2RES, Integer>("ID");
		medical_EMP_ID.setMinWidth(200);
		medical_EMP_ID.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getMedical_EMP_ID()).asObject());
		medical_EMP_ID.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_Name = new TableColumn<Medical_Lab_EMP2RES, String>(
				"Name");
		medical_EMP_Name.setMinWidth(200);
		medical_EMP_Name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_Name()));
		medical_EMP_Name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_BD = new TableColumn<Medical_Lab_EMP2RES, String>(
				"Date Of Birth");
		medical_EMP_BD.setMinWidth(200);
		medical_EMP_BD.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		medical_EMP_BD.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> address = new TableColumn<Medical_Lab_EMP2RES, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		address.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> phone = new TableColumn<Medical_Lab_EMP2RES, String>("Phone Number");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Medical_Lab_EMP2RES, Double> salary = new TableColumn<Medical_Lab_EMP2RES, Double>("Salary");
		salary.setMinWidth(170);
		salary.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getMedical_EMP_ID()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> resultTest = new TableColumn<Medical_Lab_EMP2RES, String>(
				"Result Test");
		resultTest.setMinWidth(170);
		resultTest.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		resultTest.setStyle("-fx-alignment: CENTER;");
		medical_Lab_EMP.clear();
		ResultSet rs = appyQueryOnDataBase("SELECT * from Medical_Lab_EMP2RES;");

//		Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//				String medical_EMP_address, double medical_EMP_salary, int dID, String res)
		try {
			if (rs != null)
				while (rs.next()) {

//					Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//							String medical_EMP_address,String phone, double medical_EMP_salary, String res)
					String[] birthDate = rs.getString(3).split("-");
					medical_Lab_EMP.add(new Medical_Lab_EMP2RES(Integer.parseInt(rs.getString(1)), rs.getString(2),
							new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])),
							rs.getString(4),rs.getString(5), Double.parseDouble(rs.getString(6)),
							rs.getString(7)));

				}

		} catch (NumberFormatException | SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}

		ObservableList<Medical_Lab_EMP2RES> data = FXCollections.observableArrayList(medical_Lab_EMP);

		table.setItems(data);
		table.setMaxWidth(1250);
		table.setMinHeight(180);
		table.getColumns().addAll(medical_EMP_ID, medical_EMP_Name, medical_EMP_BD, address, salary);
		return table;
	}

	private VBox menue(Stage primaryStage) {
		ImageView c = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\DOC.jpg"));
		c.setFitHeight(50);
		c.setFitWidth(50);
		Button docButton = new Button("Doctors\nPage", c);
		docButton.setFont(new Font("Times New Roman", 13));
		docButton.setMinWidth(170);
		docButton.setMinHeight(100);
		butoonEffect(docButton);

		icons(docButton);
		docButton.setEffect(new DropShadow());
		docButton.setOnAction(e -> {
			doctorButtonAction(primaryStage);
		});
		//////////////////////////////////////
		ImageView labEMP = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\Lab.png"));
		labEMP.setFitHeight(50);
		labEMP.setFitWidth(50);
		Button labEMPButton = new Button("LAB Employee\nPage", labEMP);
		labEMPButton.setFont(new Font("Times New Roman", 13));
		labEMPButton.setMinWidth(170);
		labEMPButton.setMinHeight(100);
		butoonEffect(labEMPButton);
		icons(labEMPButton);

		labEMPButton.setEffect(new DropShadow());
		labEMPButton.setOnAction(e -> {
			labButtonAction(primaryStage);
		});

		ImageView patients = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\patient.png"));
		patients.setFitHeight(50);
		patients.setFitWidth(50);
		Button patientsButton = new Button("Patients \nPage", patients);
		patientsButton.setFont(new Font("Times New Roman", 13));
		patientsButton.setMinWidth(170);
		patientsButton.setMinHeight(100);
		butoonEffect(patientsButton);

		icons(patientsButton);
		patientsButton.setEffect(new DropShadow());
		patientsButton.setOnAction(e -> {
			patientsButtonAction(primaryStage);
		});

//		ImageView rn = new ImageView(new Image("rencar.png"));
//		rn.setFitHeight(45);
//		rn.setFitWidth(55);
//		Button rentButton = new Button("Rent Buttons\nPage", rn);
//		rentButton.setFont(new Font("Times New Roman", 13));
//		rentButton.setMinWidth(170);
//		rentButton.setMinHeight(100);
//		butoonEffect(rentButton);
//
//		icons(rentButton);
//		rentButton.setEffect(new DropShadow());
//		rentButton.setOnAction(e -> {
//			rentButtonAction(primaryStage);
//		});

		ImageView m = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\logout.png"));
		m.setFitHeight(60);
		m.setFitWidth(60);
		Button logout = new Button("Logout", m);
		logout.setFont(new Font("Times New Roman", 13));
		logout.setMinWidth(170);
		logout.setMinHeight(100);
		butoonEffect(logout);

		icons(logout);
		logout.setEffect(new DropShadow());
		logout.setOnAction(e -> {
			loginPage(primaryStage);
		});

		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\house.png"));
		b.setFitHeight(50);
		b.setFitWidth(50);
		Button back = new Button("Dashborde", b);
		back.setMinHeight(100);
		back.setMinWidth(180);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());
		back.setOnAction(e -> {
			Action(primaryStage);
		});

		VBox buttons;
		if (userLogin.equals("Mohammad"))
			// buttons = new VBox(35, back, carButton, customerButton, employeeButton,
			// rentButton, logout);
			buttons = new VBox(35, back, docButton, patientsButton, labEMPButton, logout);
		else
			// buttons = new VBox(35, back, carButton, customerButton, rentButton, logout);
			// buttons = new VBox(35, back, logout);
			buttons = new VBox(35, back, docButton, patientsButton, labEMPButton, logout);
		buttons.setAlignment(Pos.CENTER);
		buttons.setStyle("-fx-border-color: #d8d9e0;" + "-fx-background-color: transparent;");

		return buttons;

	}

	private void doctorButtonAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(132);
		a.setFitWidth(140);
		Button addDoc = new Button("Add\nDoctor", a);
		addDoc.setFont(new Font("Times New Roman", 17));
		addDoc.setPrefSize(300, 200);
		butoonEffect(addDoc);

		icons(addDoc);

		addDoc.setEffect(new DropShadow());
		addDoc.setOnAction(e -> {
			addDocAction(primaryStage);
		});

		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(127);
		r.setFitWidth(140);
		Button removeDoc = new Button("Remove\nDoctor", r);
		removeDoc.setFont(new Font("Times New Roman", 17));
		icons(removeDoc);
		removeDoc.setEffect(new DropShadow());
		removeDoc.setPrefSize(300, 200);
		butoonEffect(removeDoc);

		removeDoc.setOnAction(e -> {
			deleteDocAction(primaryStage);
		});

		ImageView ed = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		ed.setFitHeight(127);
		ed.setFitWidth(140);
		Button editDocIfno = new Button("Edit\nDoctor Info", ed);
		editDocIfno.setFont(new Font("Times New Roman", 17));
		icons(editDocIfno);
		editDocIfno.setEffect(new DropShadow());
		editDocIfno.setPrefSize(300, 200);
		butoonEffect(editDocIfno);

		editDocIfno.setOnAction(e -> {
			editDocIfnoAction(primaryStage);
		});

		ImageView s = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\search.png"));
		s.setFitHeight(140);
		s.setFitWidth(140);
		Button SearchDoc = new Button("Search for\nDoctor", s);
		SearchDoc.setFont(new Font("Times New Roman", 17));
		icons(SearchDoc);
		SearchDoc.setEffect(new DropShadow());
		SearchDoc.setPrefSize(300, 200);
		butoonEffect(SearchDoc);

		SearchDoc.setOnAction(e -> {
			SearchDocAction(primaryStage);
		});
		/////

		ImageView d = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\display.png"));
		d.setFitHeight(127);
		d.setFitWidth(140);
		Button displayDocs = new Button("Display\nDoctors", d);
		displayDocs.setFont(new Font("Times New Roman", 17));
		icons(displayDocs);
		displayDocs.setEffect(new DropShadow());
		displayDocs.setPrefSize(300, 200);
		butoonEffect(displayDocs);

		displayDocs.setOnAction(e -> {
			displayDocsAction(primaryStage);
		});

		HBox h2 = new HBox(50, SearchDoc, displayDocs);
		h2.setAlignment(Pos.CENTER);

		HBox h = new HBox(60, addDoc, removeDoc, editDocIfno);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, h, h2);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void addDocAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Add Doctor");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		Label docId = new Label("Doctor Id :    ");
		docId.setPadding(new Insets(7));
		docId.setMinWidth(130);
		ComboBox<String> docIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select max(d.DID)+1 as id from Doctors d;");
		try {
			while (res.next())
				docIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		docIdt.setMinWidth(200);
		IconedTextFieled(docId, docIdt);
		HBox h = new HBox(docId, docIdt);
		h.setAlignment(Pos.CENTER_LEFT);
		
//		Doctors(int dId, String name, int salary, Date b_date, String address,String phone,String specialty)
		
		Label docName = new Label("Doctor Name: ");
		docName.setPadding(new Insets(7));
		docName.setMinWidth(130);
		TextField docNamet = new TextField();
		docNamet.setMinWidth(200);
		IconedTextFieled(docName, docNamet);
		HBox h1 = new HBox(docName, docNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h2 = new HBox(salary, salaryt);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h3 = new HBox(dateOFBirth, dateOFBirtht);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label docAdress = new Label("Doctor Address: ");
		docAdress.setPadding(new Insets(7));
		docAdress.setMinWidth(130);
		TextField docAdresst = new TextField();
		docAdresst.setMinWidth(200);
		IconedTextFieled(docAdress, docAdresst);
		HBox h4 = new HBox(docAdress, docAdresst);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label phNum = new Label("Phone Number :   ");
		phNum.setPadding(new Insets(7));
		phNum.setMinWidth(130);
		TextField phNumt = new TextField();
		phNumt.setMinWidth(200);
		IconedTextFieled(phNum, phNumt);
		HBox h5 = new HBox(phNum, phNumt);
		h5.setAlignment(Pos.CENTER_LEFT);
		
		Label specialty = new Label("Specialty :        ");
		specialty.setPadding(new Insets(7));
		specialty.setMinWidth(130);
		TextField specialtyt = new TextField();
		specialtyt.setMinWidth(200);
		IconedTextFieled(specialty, specialtyt);
		HBox h6 = new HBox(specialty, specialtyt);
		h6.setAlignment(Pos.CENTER_LEFT);


		VBox v = new VBox(15, h, h1, h2, h3, h4, h5, h6);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button add = new Button("Add Doctor", a);
		add.setPrefSize(250, 100);
		icons(add);
		butoonEffect(add);
		add.setEffect(new DropShadow());

		add.setOnAction(e -> {
			try {
//	
//				if(docIdt.getItems()==null) {
//					docIdt.getItems().add("1");
//				}else
//					docIdt.setValue(docIdt.getValue());
				LocalDate value = dateOFBirtht.getValue();
				applyOnDataBase("Insert into Doctors(DID,Dname,salary,b_date,Address,phone,Specialty) values("
						+ docIdt.getValue() + ",'" + docNamet.getText() + "','" + salaryt.getText() + "','" + value
						+ "','" + docAdresst.getText() + "','" + phNumt.getText() + "','" + specialtyt.getText() + "');");

				success.setContentText("Add Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in add !!");
				error.show();
			}
		});
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			doctorButtonAction(primaryStage);
		});
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			addDocAction(primaryStage);
		});

		HBox control = new HBox(20, add, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void deleteDocAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Remove Doctors");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label dId = new Label("Doctor Id : ");
		dId.setPadding(new Insets(7));
		dId.setMinWidth(130);
		ComboBox<String> dIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select DID from Doctors;");
		try {
			while (res.next())
				dIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		dIdt.setMinWidth(200);
		IconedTextFieled(dId, dIdt);
		HBox h7 = new HBox(dId, dIdt);
		h7.setAlignment(Pos.CENTER_LEFT);

		Label dName = new Label("Doctor Name:");
		dName.setPadding(new Insets(7));
		dName.setMinWidth(130);
		TextField dNamet = new TextField();
		dNamet.setEditable(false);
		dNamet.setMinWidth(200);
		IconedTextFieled(dName, dNamet);
		HBox h1 = new HBox(dName, dNamet);
		h1.setAlignment(Pos.CENTER_LEFT);

		Label docAdress = new Label("Doctor Address: ");
		docAdress.setPadding(new Insets(7));
		docAdress.setMinWidth(130);
		TextField docAdresst = new TextField();
		docAdresst.setMinWidth(200);
		IconedTextFieled(docAdress, docAdresst);
		HBox h3 = new HBox(docAdress, docAdresst);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h4 = new HBox(salary, salaryt);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h8 = new HBox(dateOFBirth, dateOFBirtht);
		h8.setAlignment(Pos.CENTER_LEFT);

		Label specialty = new Label("Specialty :        ");
		specialty.setPadding(new Insets(7));
		specialty.setMinWidth(130);
		TextField specialtyt = new TextField();
		specialtyt.setMinWidth(200);
		IconedTextFieled(specialty, specialtyt);
		HBox h5 = new HBox(specialty, specialtyt);
		h5.setAlignment(Pos.CENTER_LEFT);

		VBox v = new VBox(15, h7, h1, h3, h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button remove = new Button("Remove Doctor", r);
		remove.setPrefSize(250, 100);
		icons(remove);
		butoonEffect(remove);
		remove.setEffect(new DropShadow());

		remove.setOnAction(e -> {
			try {
				applyOnDataBase("delete from Doctors where DID = " + dIdt.getValue() + ";");
				success.setContentText("Delete Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			doctorButtonAction(primaryStage);
		});

		dIdt.setOnAction(e -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Doctors where DID =" + dIdt.getValue() + ";");
				rs.next();

				dNamet.setText(rs.getString(2));
				docAdresst.setText(rs.getString(5));
				specialtyt.setText(rs.getString(7));
				remove.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});
		
		ImageView r1 = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r1.setFitHeight(80);
		r1.setFitWidth(80);
		Button ref = new Button("Refresh", r1);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			deleteDocAction(primaryStage);
		});
		HBox h = new HBox(60, remove,ref, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void editDocIfnoAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Edit Doctor");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		
		Label docId = new Label("Doctor Id :    ");
		docId.setPadding(new Insets(7));
		docId.setMinWidth(130);
		ComboBox<String> docIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select DID from Doctors;");
		try {
			while (res.next())
				docIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		docIdt.setMinWidth(200);
		Button search = new Button("Search");
		IconedTextFieled(docId, docIdt);
		HBox h = new HBox(docId, docIdt);
		h.setAlignment(Pos.CENTER_LEFT);
		


		Label docName = new Label("Doctor Name: ");
		docName.setPadding(new Insets(7));
		docName.setMinWidth(130);
		TextField docNamet = new TextField();
		docNamet.setMinWidth(200);
		IconedTextFieled(docName, docNamet);
		HBox h1 = new HBox(docName, docNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		 //Doctors(int dId, String name, int salary, Date b_date, String address,String phone,String specialty)

		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h2 = new HBox(salary, salaryt);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h3 = new HBox(dateOFBirth, dateOFBirtht);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label docAdress = new Label("Doctor Address: ");
		docAdress.setPadding(new Insets(7));
		docAdress.setMinWidth(130);
		TextField docAdresst = new TextField();
		docAdresst.setMinWidth(200);
		IconedTextFieled(docAdress, docAdresst);
		HBox h4 = new HBox(docAdress, docAdresst);
		h4.setAlignment(Pos.CENTER_LEFT);
		
		Label phNum = new Label("Phone Number :   ");
		phNum.setPadding(new Insets(7));
		phNum.setMinWidth(130);
		TextField phNumt = new TextField();
		phNumt.setMinWidth(200);
		IconedTextFieled(phNum, phNumt);
		HBox h5 = new HBox(phNum, phNumt);
		h5.setAlignment(Pos.CENTER_LEFT);

		Label specialty = new Label("Specialty :        ");
		specialty.setPadding(new Insets(7));
		specialty.setMinWidth(130);
		TextField specialtyt = new TextField();
		specialtyt.setMinWidth(200);
		IconedTextFieled(specialty, specialtyt);
		HBox h6 = new HBox(specialty, specialtyt);
		h6.setAlignment(Pos.CENTER_LEFT);


		VBox v = new VBox(15, h, h1, h2, h3, h4, h5, h6);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button edit = new Button("Edit Doctor", a);
		edit.setPrefSize(250, 100);
		icons(edit);
		butoonEffect(edit);
		edit.setEffect(new DropShadow());

		edit.setOnAction(ee -> {
			try {
				// update Doctors set DID = 1, Dname = "Moh", salary = 2000, b_date =
				// "2002-08-21", Address = "Jeru", Phone = "0522222222", Specialty = "General" Where DID = 2;

				LocalDate value = dateOFBirtht.getValue();
				applyOnDataBase("update Doctors set DID = " + docIdt.getValue() + ", Dname = '" + docNamet.getText()
				+ "', salary = '" + salaryt.getText() + "', b_date = '" + value + "', Address = '"
				+ docAdresst.getText()+ "', Phone = '" + phNumt.getText() + "', Specialty = '" + specialtyt.getText() + "' WHERE DID = " + docIdt.getValue() + ";");
				success.setContentText("Success Update !!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in update !!");
				double screenWidth = 1200;
		        double screenHeight = 800;
		        error.setWidth(screenWidth);
		        error.setHeight(screenHeight);
				error.show();
			}
		});

		docIdt.setOnAction(e1 -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Doctors where DID =" + docIdt.getValue() + ";");
				rs.next();
				docNamet.setText(rs.getString(2));
				docAdresst.setText(rs.getString(5));
				salaryt.setText(rs.getString(3));
				phNumt.setText(rs.getString(6));
				specialtyt.setText(rs.getString(7));
				dateOFBirtht.setPromptText(rs.getString(4));

				edit.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});

		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			doctorButtonAction(primaryStage);
		});
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			editDocIfnoAction(primaryStage);
		});

		HBox control = new HBox(20, edit, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	@SuppressWarnings("deprecation")
	private void SearchDocAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\\\My Drive\\\\UNIVERSITY\\\\3rd year\\\\2nd Semester\\\\COMP333\\\\The Project\\\\PHASE1&2\\\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Search Doctor");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label docName = new Label("Doctor Name:");
		docName.setPadding(new Insets(7));
		docName.setMinWidth(130);
		TextField docNamet = new TextField();
		docNamet.setMinWidth(200);
		IconedTextFieled(docName, docNamet);
		HBox h1 = new HBox(docName, docNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label docid = new Label(" Doctor ID:");
		docid.setPadding(new Insets(7));
		docid.setMinWidth(130);
		TextField docidt = new TextField();
		docidt.setMinWidth(200);
		IconedTextFieled(docid, docidt);
		HBox h2 = new HBox(docid, docidt);
		h2.setAlignment(Pos.CENTER_LEFT);

		HBox v = new HBox(h1 , h2);
		v.setAlignment(Pos.CENTER);
		v.setPadding(new Insets(10));

		TableView<Doctors> table = new TableView<Doctors>();
		table.setEditable(false);

		TableColumn<Doctors, Integer> dId = new TableColumn<Doctors, Integer>("ID");
		dId.setMinWidth(200);
		dId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getdId()).asObject());
		dId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> name = new TableColumn<Doctors, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, Integer> salary = new TableColumn<Doctors, Integer>("Salary");
		salary.setMinWidth(200);
		salary.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getSalary()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> b_date = new TableColumn<Doctors, String>("Date Of Birth");
		b_date.setMinWidth(170);
		b_date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		b_date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> address = new TableColumn<Doctors, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		address.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Doctors, String> phone = new TableColumn<Doctors, String>("Phone number");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> specialty = new TableColumn<Doctors, String>("Specialty");
		specialty.setMinWidth(170);
		specialty.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		specialty.setStyle("-fx-alignment: CENTER;");

		ObservableList<Doctors> data = FXCollections.observableArrayList();
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(dId, name, salary, b_date, address, phone, specialty);
		ResultSet rs = appyQueryOnDataBase("select * from Doctors d;");
		try {
			while (rs.next()) {
				String[] birthDate = rs.getString(4).split("-");
				data.add(new Doctors(Integer.parseInt(rs.getString(1)), rs.getString(2),
						Integer.parseInt(rs.getString(3)), new Date(Integer.parseInt(birthDate[0]) - 1900,
								Integer.parseInt(birthDate[1]) - 1, Integer.parseInt(birthDate[2])),
						rs.getString(5), rs.getString(6),rs.getString(7)));
			}
		} catch (NumberFormatException | SQLException e1) {

			error.setContentText(e1.getMessage());
			error.show();
		}
		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);
		
		docidt.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs1 = appyQueryOnDataBase("select * from Doctors d where d.DID ='" + docidt.getText() + "';");
			try {
				while (rs1.next()) {
					String[] birthDate = rs1.getString(4).split("-");
					data.add(new Doctors(Integer.parseInt(rs1.getString(1)), rs1.getString(2),
							Integer.parseInt(rs1.getString(3)), new Date(Integer.parseInt(birthDate[0]) - 1900,
									Integer.parseInt(birthDate[1]) - 1, Integer.parseInt(birthDate[2])),
							rs1.getString(5), rs1.getString(6),rs1.getString(7)));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}

		});
		docNamet.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs1 = appyQueryOnDataBase("select * from Doctors d where d.Dname Like '" + docNamet.getText() + "%';");
			try {
				while (rs1.next()) {
					String[] birthDate = rs1.getString(4).split("-");
					data.add(new Doctors(Integer.parseInt(rs1.getString(1)), rs1.getString(2),
							Integer.parseInt(rs1.getString(3)), new Date(Integer.parseInt(birthDate[0]) - 1900,
									Integer.parseInt(birthDate[1]) - 1, Integer.parseInt(birthDate[2])),
							rs1.getString(5), rs1.getString(6),rs1.getString(7)));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}

		});
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);

		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			doctorButtonAction(primaryStage);
		});

		HBox h = new HBox(60, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(30, mix, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	@SuppressWarnings("deprecation")
	private void displayDocsAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Display Doctors");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		TableView<Doctors> table = new TableView<Doctors>();
		table.setEditable(false);

		TableColumn<Doctors, Integer> dId = new TableColumn<Doctors, Integer>("ID");
		dId.setMinWidth(200);
		dId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getdId()).asObject());
		dId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> name = new TableColumn<Doctors, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, Integer> salary = new TableColumn<Doctors, Integer>("Salary");
		salary.setMinWidth(200);
		salary.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getSalary()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> b_date = new TableColumn<Doctors, String>("Date Of Birth");
		b_date.setMinWidth(170);
		b_date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		b_date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> address = new TableColumn<Doctors, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		address.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Doctors, String> phone = new TableColumn<Doctors, String>("Phone number");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Doctors, String> specialty = new TableColumn<Doctors, String>("Specialty");
		specialty.setMinWidth(170);
		specialty.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getSpecialty() + ""));
		specialty.setStyle("-fx-alignment: CENTER;");
		doctors.clear();
		ResultSet rs = appyQueryOnDataBase("select * from Doctors;");

		try {
			if (rs != null)
				while (rs.next()) {

					String[] birthDate = rs.getString(4).split("-");
					doctors.add(new Doctors(Integer.parseInt(rs.getString(1)), rs.getString(2),
							Integer.parseInt(rs.getString(3)), new Date(Integer.parseInt(birthDate[0]) - 1900,
									Integer.parseInt(birthDate[1]) - 1, Integer.parseInt(birthDate[2])),
							rs.getString(5), rs.getString(6),rs.getString(7)));

				}

		} catch (NumberFormatException | SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}

		ObservableList<Doctors> data = FXCollections.observableArrayList(doctors);
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(dId, name, salary, b_date, address, phone, specialty);

		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back to\nDoctor \npage", b);
		back.setPrefSize(200, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			doctorButtonAction(primaryStage);
		});

		HBox h = new HBox(50, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(25, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	////////////////////////////////////////////////////////////
	private void patientsButtonAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);
		BorderPane pane2 = new BorderPane();

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(132);
		a.setFitWidth(140);
		Button addP = new Button("Add\nPatients", a);
		addP.setFont(new Font("Times New Roman", 17));
		addP.setPrefSize(300, 200);
		butoonEffect(addP);

		icons(addP);

		addP.setEffect(new DropShadow());
		addP.setOnAction(e -> {
			addPaAction(primaryStage);
		});

		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(127);
		r.setFitWidth(140);
		Button removeP = new Button("Remove\nPatients", r);
		removeP.setFont(new Font("Times New Roman", 17));
		icons(removeP);
		removeP.setEffect(new DropShadow());
		removeP.setPrefSize(300, 200);
		butoonEffect(removeP);

		removeP.setOnAction(e -> {
			deletePAction(primaryStage);
		});

		ImageView ed = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		ed.setFitHeight(127);
		ed.setFitWidth(140);
		Button editPIfno = new Button("Edit\nPatients Info", ed);
		editPIfno.setFont(new Font("Times New Roman", 17));
		icons(editPIfno);
		editPIfno.setEffect(new DropShadow());
		editPIfno.setPrefSize(300, 200);
		butoonEffect(editPIfno);

		editPIfno.setOnAction(e -> {
			editPIfnoAction(primaryStage);
		});

		ImageView s = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\search.png"));
		s.setFitHeight(140);
		s.setFitWidth(140);
		Button SearchP = new Button("Search for\nPatients", s);
		SearchP.setFont(new Font("Times New Roman", 17));
		icons(SearchP);
		SearchP.setEffect(new DropShadow());
		SearchP.setPrefSize(300, 200);
		butoonEffect(SearchP);

		SearchP.setOnAction(e -> {
			SearchPAction(primaryStage);
		});
		/////

		ImageView d = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\display.png"));
		d.setFitHeight(127);
		d.setFitWidth(140);
		Button displayP = new Button("Display\nPatients", d);
		displayP.setFont(new Font("Times New Roman", 17));
		icons(displayP);
		displayP.setEffect(new DropShadow());
		displayP.setPrefSize(300, 200);
		butoonEffect(displayP);

		displayP.setOnAction(e -> {
			displayPAction(primaryStage);
		});
		HBox h2 = new HBox(50, SearchP, displayP);
		h2.setAlignment(Pos.CENTER);

		HBox h = new HBox(60, addP, removeP, editPIfno);

		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, h, h2);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	@SuppressWarnings("deprecation")
	private void displayPAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Display Patients");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		TableView<Patients> table = new TableView<Patients>();
		table.setEditable(false);

		TableColumn<Patients, Integer> pId = new TableColumn<Patients, Integer>("ID");
		pId.setMinWidth(200);
		pId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getpId()).asObject());
		pId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> name = new TableColumn<Patients, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getpName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> date = new TableColumn<Patients, String>("Date Of Birth");
		date.setMinWidth(170);
		date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> address = new TableColumn<Patients, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getAddress() + ""));
		address.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> checkups = new TableColumn<Patients, String>("checkups");
		checkups.setMinWidth(170);
		checkups.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getChekups() + ""));
		checkups.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> insurance = new TableColumn<Patients, String>("Expiration of insurance");
		insurance.setMinWidth(170);
		insurance.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getINSOFBirth() + ""));
		insurance.setStyle("-fx-alignment: CENTER;");
		patients.clear();
		ResultSet rs = appyQueryOnDataBase("SELECT * FROM Patients;");
		try {
//			Patients(int pId, String pName, Date date, String address, String chekups,String phone,Date insurance)
			if (rs != null)
				while (rs.next()) {
					String[] birthDate = rs.getString(3).split("-");
					String[] inDate = rs.getString(7).split("-");
					patients.add(new Patients(Integer.parseInt(rs.getString(1)), rs.getString(2),
							new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])),
							rs.getString(4), rs.getString(5),rs.getString(6), new Date(Integer.parseInt(inDate[0]) - 1900,
									Integer.parseInt(inDate[1]) - 1, Integer.parseInt(inDate[2]))));

				}

		} catch (NumberFormatException | SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}

		ObservableList<Patients> data = FXCollections.observableArrayList(patients);
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(pId, name, date, address, insurance);
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back to\nPatients \npage", b);
		back.setPrefSize(200, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			patientsButtonAction(primaryStage);
		});

		HBox h = new HBox(50, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(25, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	@SuppressWarnings("deprecation")
	private void SearchPAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Search Patients");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label pName = new Label("Patient Name:");
		pName.setPadding(new Insets(7));
		pName.setMinWidth(130);
		TextField pNamet = new TextField();
		pNamet.setMinWidth(200);
		IconedTextFieled(pName, pNamet);
		HBox h1 = new HBox(pName, pNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label pid = new Label(" Patient ID:");
		pid.setPadding(new Insets(7));
		pid.setMinWidth(130);
		TextField pidt = new TextField();
		pidt.setMinWidth(200);
		IconedTextFieled(pid, pidt);
		HBox h2 = new HBox(pid, pidt);
		h2.setAlignment(Pos.CENTER_LEFT);

		HBox v = new HBox(h1 , h2);
		v.setAlignment(Pos.CENTER);
		v.setPadding(new Insets(10));

		TableView<Patients> table = new TableView<Patients>();
		table.setEditable(false);

		TableColumn<Patients, Integer> pId = new TableColumn<Patients, Integer>("ID");
		pId.setMinWidth(200);
		pId.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getpId()).asObject());
		pId.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> name = new TableColumn<Patients, String>("Name");
		name.setMinWidth(200);
		name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getpName()));
		name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> date = new TableColumn<Patients, String>("Date Of Birth");
		date.setMinWidth(170);
		date.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		date.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> address = new TableColumn<Patients, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getAddress() + ""));
		address.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> checkups = new TableColumn<Patients, String>("checkups");
		checkups.setMinWidth(170);
		checkups.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getChekups() + ""));
		checkups.setStyle("-fx-alignment: CENTER;");

		TableColumn<Patients, String> insurance = new TableColumn<Patients, String>("Expiration of insurance");
		insurance.setMinWidth(170);
		insurance.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getINSOFBirth() + ""));
		insurance.setStyle("-fx-alignment: CENTER;");
		patients.clear();
		ObservableList<Patients> data = FXCollections.observableArrayList(patients);
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(pId, name, date, address, insurance);
		ResultSet rs = appyQueryOnDataBase("select * from Patients p;");
		try {
			while (rs.next()) {
				String[] birthDate = rs.getString(3).split("-");
				String[] insDate = rs.getString(7).split("-");
				data.add(new Patients(Integer.parseInt(rs.getString(1)), rs.getString(2),
						new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
								Integer.parseInt(birthDate[2])),
						rs.getString(4), rs.getString(5),rs.getString(6), new Date(Integer.parseInt(insDate[0]) - 1900,
								Integer.parseInt(insDate[1]) - 1, Integer.parseInt(insDate[2]))));
			}
		} catch (NumberFormatException | SQLException e1) {

			error.setContentText(e1.getMessage());
			error.show();
		}

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);
		
		pNamet.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs1 = appyQueryOnDataBase(
					"select * from Patients p where p.Pname Like '" + pNamet.getText() + "%';");
			try {
				while (rs1.next()) {
					String[] birthDate = rs1.getString(3).split("-");
					String[] insDate = rs1.getString(7).split("-");
					data.add(new Patients(Integer.parseInt(rs1.getString(1)), rs1.getString(2),
							new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])),
							rs1.getString(4), rs1.getString(5),rs1.getString(6), new Date(Integer.parseInt(insDate[0]) - 1900,
									Integer.parseInt(insDate[1]) - 1, Integer.parseInt(insDate[2]))));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}
		});
		
		pidt.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs2 = appyQueryOnDataBase(
					"select * from Patients p where p.PID = '" + pidt.getText() + "';");
			try {
				while (rs2.next()) {
					String[] birthDate = rs2.getString(3).split("-");
					String[] insDate = rs2.getString(7).split("-");
					data.add(new Patients(Integer.parseInt(rs2.getString(1)), rs2.getString(2),
							new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])),
							rs2.getString(4), rs2.getString(5),rs2.getString(6), new Date(Integer.parseInt(insDate[0]) - 1900,
									Integer.parseInt(insDate[1]) - 1, Integer.parseInt(insDate[2]))));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}
		});
		
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			patientsButtonAction(primaryStage);
		});

		HBox h = new HBox(60, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(30, mix, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	private void editPIfnoAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Edit Patients");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label pId = new Label("Patients Id :    ");
		pId.setPadding(new Insets(7));
		pId.setMinWidth(130);
		ComboBox<String> pIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select PID from Patients;");
		try {
			while (res.next())
				pIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		pIdt.setMinWidth(200);
//		Button search = new Button("Search");
		IconedTextFieled(pId, pIdt);
		HBox h = new HBox(pId, pIdt);
		h.setAlignment(Pos.CENTER_LEFT);

		Label newPID = new Label("set new ID [Optional]: ");
		newPID.setPadding(new Insets(7));
		newPID.setMinWidth(130);
		TextField pNewIDt = new TextField();
		pNewIDt.setMinWidth(200);
		IconedTextFieled(newPID, pNewIDt);
		HBox h1 = new HBox(newPID, pNewIDt);
		h1.setAlignment(Pos.CENTER_LEFT);

		Label pName = new Label("Patient Name: ");
		pName.setPadding(new Insets(7));
		pName.setMinWidth(130);
		TextField pNamet = new TextField();
		pNamet.setMinWidth(200);
		IconedTextFieled(pName, pNamet);
		HBox h2 = new HBox(pName, pNamet);
		h2.setAlignment(Pos.CENTER_LEFT);

		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h3 = new HBox(dateOFBirth, dateOFBirtht);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label pAddress = new Label("Patient Address: ");
		pAddress.setPadding(new Insets(7));
		pAddress.setMinWidth(130);
		TextField pAddresst = new TextField();
		pAddresst.setMinWidth(200);
		IconedTextFieled(pAddress, pAddresst);
		HBox h4 = new HBox(pAddress, pAddresst);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label check = new Label("Check Up :       ");
		check.setPadding(new Insets(7));
		check.setMinWidth(130);
		TextField checkt = new TextField();
		checkt.setMinWidth(200);
		IconedTextFieled(check, checkt);
		HBox h5 = new HBox(check, checkt);
		h5.setAlignment(Pos.CENTER_LEFT);
		
		Label pNo = new Label("Phone Number :       ");
		pNo.setPadding(new Insets(7));
		pNo.setMinWidth(130);
		TextField pNot = new TextField();
		pNot.setMinWidth(200);
		IconedTextFieled(pNo, pNot);
		HBox h6 = new HBox(pNo, pNot);
		h6.setAlignment(Pos.CENTER_LEFT);

		Label dateOFInsurance = new Label("Date of Insurance :");
		dateOFInsurance.setPadding(new Insets(7));
		dateOFInsurance.setMinWidth(130);
		DatePicker dateOFInsurancet = new DatePicker();
		dateOFInsurancet.setEditable(false);
		dateOFInsurancet.setMinWidth(200);
		IconedTextFieled(dateOFInsurance, dateOFInsurancet);
		HBox h7 = new HBox(dateOFInsurance, dateOFInsurancet);
		h7.setAlignment(Pos.CENTER_LEFT);

		VBox v = new VBox(15, h, h1, h2, h3, h4, h6, h7);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button edit = new Button("Edit Patient", a);
		edit.setPrefSize(250, 100);
		icons(edit);
		butoonEffect(edit);
		edit.setEffect(new DropShadow());

		edit.setOnAction(ee -> {
			try {
				if(pNewIDt.getText().isBlank()) {
					pNewIDt.setText(pIdt.getValue());
				}else
					pNewIDt.setText(pNewIDt.getText());
				// Patients(int pId, String pName, Date date, String address, String
				// chekups,Date insurance)
				LocalDate value = dateOFBirtht.getValue();
				LocalDate value1 = dateOFInsurancet.getValue();

				applyOnDataBase("UPDATE Patients SET PID = " + pNewIDt.getText() + ", Pname = '" + pNamet.getText()
						+ "', b_date = '" + value + "', address = '" + pAddresst.getText() + "', check_ups = '"
						+ checkt.getText() + "', Phone = '" + pNot.getText() 
						+ "', insurance = '" + value1 + "' WHERE PID = " + pIdt.getValue() + ";");

				success.setContentText("Success Update !!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in update !!");
				error.show();
			}
		});

		pIdt.setOnAction(e1 -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Patients where PID =" + pIdt.getValue() + ";");
				rs.next();
				pNamet.setText(rs.getString(2));
				dateOFBirtht.setPromptText(rs.getString(3));
				pAddresst.setText(rs.getString(4));
//				checkt.setText(rs.getString(5));
				pNot.setText(rs.getString(6));
				dateOFInsurancet.setPromptText(rs.getString(7));

				edit.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});

		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			patientsButtonAction(primaryStage);
		});
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		
		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			editPIfnoAction(primaryStage);
		});
		

		HBox control = new HBox(20, edit, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	private void deletePAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Remove Patients");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label pId = new Label("Patients Id : ");
		pId.setPadding(new Insets(7));
		pId.setMinWidth(130);
		ComboBox<String> pIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select PID from Patients;");
		try {
			while (res.next())
				pIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		pIdt.setMinWidth(200);
		IconedTextFieled(pId, pIdt);
		HBox h = new HBox(pId, pIdt);
		h.setAlignment(Pos.CENTER_LEFT);

		Label pName = new Label("Patient Name: ");
		pName.setPadding(new Insets(7));
		pName.setMinWidth(130);
		TextField pNamet = new TextField();
		pNamet.setMinWidth(200);
		IconedTextFieled(pName, pNamet);
		HBox h1 = new HBox(pName, pNamet);
		h1.setAlignment(Pos.CENTER_LEFT);

		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h2 = new HBox(dateOFBirth, dateOFBirtht);
		h2.setAlignment(Pos.CENTER_LEFT);

		Label pAddress = new Label("Patients Address: ");
		pAddress.setPadding(new Insets(7));
		pAddress.setMinWidth(130);
		TextField pAddresst = new TextField();
		pAddresst.setMinWidth(200);
		IconedTextFieled(pAddress, pAddresst);
		HBox h3 = new HBox(pAddress, pAddresst);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label check = new Label("Chekups :         ");
		check.setPadding(new Insets(7));
		check.setMinWidth(130);
		TextField checkt = new TextField();
		checkt.setMinWidth(200);
		IconedTextFieled(check, checkt);
		HBox h4 = new HBox(check, checkt);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label dateOFInsurance = new Label("Date of Insurance :");
		dateOFInsurance.setPadding(new Insets(7));
		dateOFInsurance.setMinWidth(130);
		DatePicker dateOFInsurancet = new DatePicker();
		dateOFInsurancet.setEditable(false);
		dateOFInsurancet.setMinWidth(200);
		IconedTextFieled(dateOFInsurance, dateOFInsurancet);
		HBox h5 = new HBox(dateOFInsurance, dateOFInsurancet);
		h5.setAlignment(Pos.CENTER_LEFT);

		VBox v = new VBox(15, h, h1, h2, h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button remove = new Button("Remove Patient", r);
		remove.setPrefSize(250, 100);
		icons(remove);
		butoonEffect(remove);
		remove.setEffect(new DropShadow());

		remove.setOnAction(e -> {
			try {
				applyOnDataBase("delete from Patients where PID = " + pIdt.getValue() + ";");
				success.setContentText("Delete Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});
		
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		ImageView re = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		re.setFitHeight(80);
		re.setFitWidth(80);
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			patientsButtonAction(primaryStage);
		});

		Button ref = new Button("Refresh", re);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			deletePAction(primaryStage);
		});
		
		
		pIdt.setOnAction(e -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Patients where PID =" + pIdt.getValue() + ";");
				rs.next();
				// id name date date
				pNamet.setText(rs.getString(2));
				pAddresst.setText(rs.getString(3));
				dateOFBirtht.setPromptText(rs.getString(3));
				dateOFInsurancet.setPromptText(rs.getString(7));
				remove.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});

		HBox hh = new HBox(60, remove, ref, back);
		hh.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, hh);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	private void addPaAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Add Patient");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label pId = new Label("Patient Id :    ");
		pId.setPadding(new Insets(7));
		pId.setMinWidth(130);
		ComboBox<String> pIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select max(p.PID)+1 as id from Patients p;");
		try {
			while (res.next())
				pIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		pIdt.setMinWidth(200);
		IconedTextFieled(pId, pIdt);
		HBox h = new HBox(pId, pIdt);
		h.setAlignment(Pos.CENTER_LEFT);

		Label pName = new Label("Patient Name: ");
		pName.setPadding(new Insets(7));
		pName.setMinWidth(130);
		TextField pNamet = new TextField();
		pNamet.setMinWidth(200);
		IconedTextFieled(pName, pNamet);
		HBox h1 = new HBox(pName, pNamet);
		h1.setAlignment(Pos.CENTER_LEFT);

		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h2 = new HBox(dateOFBirth, dateOFBirtht);
		h2.setAlignment(Pos.CENTER_LEFT);

		Label pAddress = new Label("Patient Address: ");
		pAddress.setPadding(new Insets(7));
		pAddress.setMinWidth(130);
		TextField pAddresst = new TextField();
		pAddresst.setMinWidth(200);
		IconedTextFieled(pAddress, pAddresst);
		HBox h3 = new HBox(pAddress, pAddresst);
		h3.setAlignment(Pos.CENTER_LEFT);

		Label check = new Label("Chekups :         ");
		check.setPadding(new Insets(7));
		check.setMinWidth(130);
		TextField checkt = new TextField();
		checkt.setMinWidth(200);
		IconedTextFieled(check, checkt);
		HBox h4 = new HBox(check, checkt);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label dateOFInsurance = new Label("End of Insurance :");
		dateOFInsurance.setPadding(new Insets(7));
		dateOFInsurance.setMinWidth(130);
		DatePicker dateOFInsurancet = new DatePicker();
		dateOFInsurancet.setEditable(false);
		dateOFInsurancet.setMinWidth(200);
		IconedTextFieled(dateOFInsurance, dateOFInsurancet);
		HBox h5 = new HBox(dateOFInsurance, dateOFInsurancet);
		h5.setAlignment(Pos.CENTER_LEFT);

		Label phNum = new Label("Phone Number :   ");
		phNum.setPadding(new Insets(7));
		phNum.setMinWidth(130);
		TextField phNumt = new TextField();
		phNumt.setMinWidth(200);
		IconedTextFieled(phNum, phNumt);
		HBox h9 = new HBox(phNum, phNumt);
		h9.setAlignment(Pos.CENTER_LEFT);

		VBox v = new VBox(15, h, h1, h2, h3,h9, h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button add = new Button("Add Patients", a);
		add.setPrefSize(250, 100);
		icons(add);
		butoonEffect(add);
		add.setEffect(new DropShadow());

		add.setOnAction(e -> {
			try {
				if(pIdt.getValue()==null) {
					pIdt.setValue(Integer.toString(1));
				}
//			Patients(int pId, String pName, Date date, String address, String chekups,Date insurance)
				LocalDate value = dateOFBirtht.getValue();
				LocalDate value2 = dateOFInsurancet.getValue();
				applyOnDataBase("Insert into Patients(PID,Pname,b_date,address,check_ups,Phone,insurance) values("
						+ pIdt.getValue() + ",'" + pNamet.getText() + "','" + value + "','" + pAddresst.getText()
						+ "','" + checkt.getText() + "','" + phNumt.getText() + "','" + value2 + "');");

				success.setContentText("Add Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in add !!");
				error.show();
			}
		});
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			patientsButtonAction(primaryStage);
		});

		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			addPaAction(primaryStage);
		});

		HBox control = new HBox(20, add, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

/////////////////////////////////////////////////////////////////////
	private void labButtonAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);
		BorderPane pane2 = new BorderPane();

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(132);
		a.setFitWidth(140);
		Button addLEmp = new Button("Add LAB\nEmployee", a);
		addLEmp.setFont(new Font("Times New Roman", 17));
		addLEmp.setPrefSize(300, 200);
		butoonEffect(addLEmp);

		icons(addLEmp);

		addLEmp.setEffect(new DropShadow());
		addLEmp.setOnAction(e -> {
			addLabAction(primaryStage);
		});

		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(127);
		r.setFitWidth(140);
		Button removeLEmp = new Button("Remove LAB\nEmployee", r);
		removeLEmp.setFont(new Font("Times New Roman", 17));
		icons(removeLEmp);
		removeLEmp.setEffect(new DropShadow());
		removeLEmp.setPrefSize(300, 200);
		butoonEffect(removeLEmp);

		removeLEmp.setOnAction(e -> {
			deleteLabAction(primaryStage);
		});

		ImageView ed = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		ed.setFitHeight(127);
		ed.setFitWidth(140);
		Button editLabIfno = new Button("Edit LAB\nEmployee Info", ed);
		editLabIfno.setFont(new Font("Times New Roman", 17));
		icons(editLabIfno);
		editLabIfno.setEffect(new DropShadow());
		editLabIfno.setPrefSize(300, 200);
		butoonEffect(editLabIfno);

		editLabIfno.setOnAction(e -> {
			editLabIfnoAction(primaryStage);
		});

		ImageView s = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\search.png"));
		s.setFitHeight(140);
		s.setFitWidth(140);
		Button SearchLabEmp = new Button("Search for\nLAB Employee", s);
		SearchLabEmp.setFont(new Font("Times New Roman", 17));
		icons(SearchLabEmp);
		SearchLabEmp.setEffect(new DropShadow());
		SearchLabEmp.setPrefSize(300, 200);
		butoonEffect(SearchLabEmp);

		SearchLabEmp.setOnAction(e -> {
			SearchLabAction(primaryStage);
		});
		/////

		ImageView d = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\display.png"));
		d.setFitHeight(127);
		d.setFitWidth(140);
		Button displayLEmp = new Button("Display LAB\n Employee", d);
		displayLEmp.setFont(new Font("Times New Roman", 17));
		icons(displayLEmp);
		displayLEmp.setEffect(new DropShadow());
		displayLEmp.setPrefSize(300, 200);
		butoonEffect(displayLEmp);

		displayLEmp.setOnAction(e -> {
			displayLabAction(primaryStage);
		});
		HBox h2 = new HBox(50, SearchLabEmp, displayLEmp);
		h2.setAlignment(Pos.CENTER);

		HBox h = new HBox(60, addLEmp, removeLEmp, editLabIfno);

		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, h, h2);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	@SuppressWarnings("deprecation")
	private void displayLabAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Display Lab Employee");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		
//		Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//				String medical_EMP_address, double medical_EMP_salary, int dID, String res)
		TableView<Medical_Lab_EMP2RES> table = new TableView<Medical_Lab_EMP2RES>();
		table.setEditable(false);

		TableColumn<Medical_Lab_EMP2RES, Integer> medical_EMP_ID = new TableColumn<Medical_Lab_EMP2RES, Integer>("ID");
		medical_EMP_ID.setMinWidth(200);
		medical_EMP_ID.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getMedical_EMP_ID()).asObject());
		medical_EMP_ID.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_Name = new TableColumn<Medical_Lab_EMP2RES, String>("Name");
		medical_EMP_Name.setMinWidth(200);
		medical_EMP_Name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_Name()));
		medical_EMP_Name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_BD = new TableColumn<Medical_Lab_EMP2RES, String>(
				"Date Of Birth");
		medical_EMP_BD.setMinWidth(200);
		medical_EMP_BD.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		medical_EMP_BD.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> address = new TableColumn<Medical_Lab_EMP2RES, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		address.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Medical_Lab_EMP2RES, String> phone = new TableColumn<Medical_Lab_EMP2RES, String>("Phone");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, Double> salary = new TableColumn<Medical_Lab_EMP2RES, Double>("Salary");
		salary.setMinWidth(170);
		salary.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getMedical_EMP_salary()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");
		
		
		

		TableColumn<Medical_Lab_EMP2RES, String> resultTest = new TableColumn<Medical_Lab_EMP2RES, String>("Result Test");
		resultTest.setMinWidth(170);
		resultTest.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		resultTest.setStyle("-fx-alignment: CENTER;");
		medical_Lab_EMP.clear();
		ResultSet rs = appyQueryOnDataBase("SELECT * from Medical_Lab_EMP2RES;");

//		Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//				String medical_EMP_address,String phone, double medical_EMP_salary, String res)
		try {
			while (rs.next()) {
				String[] birthDate = rs.getString(3).split("-");
				medical_Lab_EMP.add(new Medical_Lab_EMP2RES(Integer.parseInt(rs.getString(1)), rs.getString(2),
						new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
						Integer.parseInt(birthDate[2])), rs.getString(4),rs.getString(5) ,Double.parseDouble(rs.getString(5)),
						rs.getString(7)));
			}
		} catch (NumberFormatException | SQLException e1) {

			error.setContentText(e1.getMessage());
			error.show();
		}
		

		ObservableList<Medical_Lab_EMP2RES> data = FXCollections.observableArrayList(medical_Lab_EMP);
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(medical_EMP_ID, medical_EMP_Name, medical_EMP_BD, address, salary);
		
		ImageView b = new ImageView(new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back to\nLab employee \npage", b);
		back.setPrefSize(200, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			labButtonAction(primaryStage);
		});

		HBox h = new HBox(50, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(25, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	@SuppressWarnings("deprecation")
	private void SearchLabAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);
		
		BorderPane pane2 = new BorderPane();
		
		Label title = new Label("Search for lab Employee");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		Label lName = new Label("lab Employee Name: ");
		lName.setPadding(new Insets(7));
		lName.setMinWidth(130);
		TextField lNamet = new TextField();
		lNamet.setMinWidth(200);
		IconedTextFieled(lName, lNamet);
		HBox h1 = new HBox(lName, lNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label lid = new Label(" lab Employee ID:");
		lid.setPadding(new Insets(7));
		lid.setMinWidth(130);
		TextField lidt = new TextField();
		lidt.setMinWidth(200);
		IconedTextFieled(lid, lidt);
		HBox h2 = new HBox(lid, lidt);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		HBox v = new HBox(h1, h2);
		v.setAlignment(Pos.CENTER);
		v.setPadding(new Insets(10));
		TableView<Medical_Lab_EMP2RES> table = new TableView<Medical_Lab_EMP2RES>();
		table.setEditable(false);

		TableColumn<Medical_Lab_EMP2RES, Integer> medical_EMP_ID = new TableColumn<Medical_Lab_EMP2RES, Integer>("ID");
		medical_EMP_ID.setMinWidth(200);
		medical_EMP_ID.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().getMedical_EMP_ID()).asObject());
		medical_EMP_ID.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_Name = new TableColumn<Medical_Lab_EMP2RES, String>("Name");
		medical_EMP_Name.setMinWidth(200);
		medical_EMP_Name.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_Name()));
		medical_EMP_Name.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> medical_EMP_BD = new TableColumn<Medical_Lab_EMP2RES, String>(
				"Date Of Birth");
		medical_EMP_BD.setMinWidth(200);
		medical_EMP_BD.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getDateOFBirth() + ""));
		medical_EMP_BD.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, String> address = new TableColumn<Medical_Lab_EMP2RES, String>("Address");
		address.setMinWidth(170);
		address.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		address.setStyle("-fx-alignment: CENTER;");
		
		TableColumn<Medical_Lab_EMP2RES, String> phone = new TableColumn<Medical_Lab_EMP2RES, String>("Phone");
		phone.setMinWidth(170);
		phone.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getPhone() + ""));
		phone.setStyle("-fx-alignment: CENTER;");

		TableColumn<Medical_Lab_EMP2RES, Double> salary = new TableColumn<Medical_Lab_EMP2RES, Double>("Salary");
		salary.setMinWidth(170);
		salary.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getMedical_EMP_salary()).asObject());
		salary.setStyle("-fx-alignment: CENTER;");
		
		

		TableColumn<Medical_Lab_EMP2RES, String> resultTest = new TableColumn<Medical_Lab_EMP2RES, String>("Result Test");
		resultTest.setMinWidth(170);
		resultTest.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getMedical_EMP_address() + ""));
		resultTest.setStyle("-fx-alignment: CENTER;");
		medical_Lab_EMP.clear();
		
		ObservableList<Medical_Lab_EMP2RES> data = FXCollections.observableArrayList(medical_Lab_EMP);
		
		table.setItems(data);
		table.setMaxWidth(1300);
		table.setMinHeight(450);
		table.getColumns().addAll(medical_EMP_ID, medical_EMP_Name, medical_EMP_BD, address,phone, salary);
		ResultSet rs = appyQueryOnDataBase("select * from Medical_Lab_EMP2RES;");
		try {
			while (rs.next()) {
				String[] birthDate = rs.getString(3).split("-");
				data.add(new Medical_Lab_EMP2RES(Integer.parseInt(rs.getString(1)),
						rs.getString(2),new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
								Integer.parseInt(birthDate[2])), rs.getString(4), rs.getString(5),
						Double.parseDouble(rs.getString(6)),rs.getString(7)));
			}
		} catch (NumberFormatException | SQLException e1) {

			error.setContentText(e1.getMessage());
			error.show();
		}
		
		
		
		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);
		
		lNamet.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs1 = appyQueryOnDataBase(
					"select * from Medical_Lab_EMP2RES l where l.MLEName Like '" + lNamet.getText() + "%';");
			try {
				while (rs1.next()) {
					
//					Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//							String medical_EMP_address,String phone, double medical_EMP_salary, String res)
					
					String[] birthDate = rs1.getString(3).split("-");
					data.add(new Medical_Lab_EMP2RES(Integer.parseInt(rs1.getString(1)),
							rs1.getString(2),new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])), rs1.getString(4), rs1.getString(5),
							Double.parseDouble(rs1.getString(6)),rs1.getString(7)));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}
		});
		
		lidt.setOnKeyTyped(e -> {
			data.clear();
			ResultSet rs1 = appyQueryOnDataBase(
					"select * from Medical_Lab_EMP2RES l where l.MLEID = '" + lidt.getText() + "';");
			try {
				while (rs1.next()) {
					
//					Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//							String medical_EMP_address,String phone, double medical_EMP_salary, String res)
					
					String[] birthDate = rs1.getString(3).split("-");
					data.add(new Medical_Lab_EMP2RES(Integer.parseInt(rs1.getString(1)),
							rs1.getString(2),new Date(Integer.parseInt(birthDate[0]) - 1900, Integer.parseInt(birthDate[1]) - 1,
									Integer.parseInt(birthDate[2])), rs1.getString(4), rs1.getString(5),
							Double.parseDouble(rs1.getString(6)),rs1.getString(7)));
				}
			} catch (NumberFormatException | SQLException e1) {

				error.setContentText(e1.getMessage());
				error.show();
			}
		});
		
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			labButtonAction(primaryStage);
		});

		HBox h = new HBox(60, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(30, mix, table, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	
	
	private void editLabIfnoAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();
		
		Label title = new Label("Edit Lab Employee Info");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		Label lId = new Label("Employee Id :    ");
		lId.setPadding(new Insets(7));
		lId.setMinWidth(130);
		ComboBox<String> lIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select MLEID from Medical_Lab_EMP2RES;");
		try {
			while (res.next())
				lIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		lIdt.setMinWidth(200);
		Button search = new Button("Search");
		IconedTextFieled(lId, lIdt);
		HBox h = new HBox(lId, lIdt);
		h.setAlignment(Pos.CENTER_LEFT);
		
		//Medical_Lab_EMP2RES(MLEID,MLEName,b_date,address,Phone,salary)

		Label lName = new Label("Employee Name: ");
		lName.setPadding(new Insets(7));
		lName.setMinWidth(130);
		TextField lNamet = new TextField();
		lNamet.setMinWidth(200);
		IconedTextFieled(lName, lNamet);
		HBox h1 = new HBox(lName, lNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h2 = new HBox(dateOFBirth, dateOFBirtht);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		Label lAddress = new Label("Employee Address: ");
		lAddress.setPadding(new Insets(7));
		lAddress.setMinWidth(130);
		TextField lAddresst = new TextField();
		lAddresst.setMinWidth(200);
		IconedTextFieled(lAddress, lAddresst);
		HBox h3 = new HBox(lAddress, lAddresst);
		h3.setAlignment(Pos.CENTER_LEFT);
		
		Label phNum = new Label("Phone Number :   ");
		phNum.setPadding(new Insets(7));
		phNum.setMinWidth(130);
		TextField phNumt = new TextField();
		phNumt.setMinWidth(200);
		IconedTextFieled(phNum, phNumt);
		HBox h4 = new HBox(phNum, phNumt);
		h4.setAlignment(Pos.CENTER_LEFT);
		
		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h5 = new HBox(salary, salaryt);
		h5.setAlignment(Pos.CENTER_LEFT);
		
		Label resu = new Label("result :        ");
		resu.setPadding(new Insets(7));
		resu.setMinWidth(130);
		TextField resut = new TextField();
		resut.setMinWidth(200);
		IconedTextFieled(resu, resut);
		HBox h6 = new HBox(resu, resut);
		h6.setAlignment(Pos.CENTER_LEFT);
		
		VBox v = new VBox(15, h, h1, h2, h3, h4, h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));
		
		
		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\edit.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button edit = new Button("Edit Lab Worker", a);
		edit.setPrefSize(250, 100);
		icons(edit);
		butoonEffect(edit);
		edit.setEffect(new DropShadow());

		edit.setOnAction(ee -> {
			try {	
				// update Doctors set MLEID = 1, MLEName = "Moh", b_date = "2002-08-21", Address = "Jeru",
				//Phone = "0522222222" , salary = 2000 , result = "iufohu" Where MLEID = 2;

//				Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//				String medical_EMP_address,String phone, double medical_EMP_salary, String res)
				
				LocalDate value = dateOFBirtht.getValue();
				applyOnDataBase("update Medical_Lab_EMP2RES set MLEID = " + lIdt.getValue() + ", MLEName = '" + lNamet.getText()
				+ "', b_date = '" + value + "', Address = '" + lAddresst.getText()+ "', Phone = '" + phNumt.getText()
				+ "', salary = '" + salaryt.getText() +"', result = '" + " " + "' WHERE MLEID = " + lIdt.getValue() + ";");
				success.setContentText("Success Update !!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in update !!");
				double screenWidth = 1200;
		        double screenHeight = 800;
		        error.setWidth(screenWidth);
		        error.setHeight(screenHeight);
				error.show();
			}
		});

		lIdt.setOnAction(e1 -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Medical_Lab_EMP2RES where MLEID =" + lIdt.getValue() + ";");
				rs.next();
				lNamet.setText(rs.getString(2));
				dateOFBirtht.setPromptText(rs.getString(3));
				lAddresst.setText(rs.getString(4));
				phNumt.setText(rs.getString(5));
				salaryt.setText(rs.getString(6));
				edit.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});

		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			labButtonAction(primaryStage);
		});
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			editLabIfnoAction(primaryStage);
		});

		HBox control = new HBox(20, edit, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
		

	}

	private void deleteLabAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Remove Lab Employee");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label lId = new Label("Employee Id : ");
		lId.setPadding(new Insets(7));
		lId.setMinWidth(130);
		ComboBox<String> lIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select MLEID from Medical_Lab_EMP2RES;");
		try {
			while (res.next())
				lIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		lIdt.setMinWidth(200);
		IconedTextFieled(lId, lIdt);
		HBox h = new HBox(lId, lIdt);
		h.setAlignment(Pos.CENTER_LEFT);
		
		Label lName = new Label("Employee Name:");
		lName.setPadding(new Insets(7));
		lName.setMinWidth(130);
		TextField lNamet = new TextField();
		lNamet.setEditable(false);
		lNamet.setMinWidth(200);
		IconedTextFieled(lName, lNamet);
		HBox h1 = new HBox(lName, lNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label lPh = new Label("Employee Phone:");
		lPh.setPadding(new Insets(7));
		lPh.setMinWidth(130);
		TextField lPht = new TextField();
		lPht.setEditable(false);
		lPht.setMinWidth(200);
		IconedTextFieled(lPh, lPht);
		HBox h2 = new HBox(lPh, lPht);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h3 = new HBox(salary, salaryt);
		h3.setAlignment(Pos.CENTER_LEFT);
		
		VBox v = new VBox(15, h, h1, h2, h3);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\remove.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button remove = new Button("Remove Employee", r);
		remove.setPrefSize(250, 100);
		icons(remove);
		butoonEffect(remove);
		remove.setEffect(new DropShadow());
		
		remove.setOnAction(e -> {
			try {
				applyOnDataBase("delete from Medical_Lab_EMP2RES where MLEID = " + lIdt.getValue() + ";");
				success.setContentText("Delete Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});
		
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			labButtonAction(primaryStage);
		});
		
		lIdt.setOnAction(e -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Medical_Lab_EMP2RES where MLEID =" + lIdt.getValue() + ";");
				rs.next();
				lNamet.setText(rs.getString(2));
				lPht.setText(rs.getString(5));
				salaryt.setText(rs.getString(6));
				remove.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});
		
		ImageView r1 = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r1.setFitHeight(80);
		r1.setFitWidth(80);
		Button ref = new Button("Refresh", r1);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			deleteLabAction(primaryStage);
		});
		HBox hh = new HBox(60, remove,ref, back);
		hh.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, hh);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	private void addLabAction(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\wall3.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Add Lab Employee");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		
		
		Label lId = new Label("Employee Id :    ");
		lId.setPadding(new Insets(7));
		lId.setMinWidth(130);
		ComboBox<String> lIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select max(l.MLEID)+1 as id from Medical_Lab_EMP2RES l;");
		try {
			while (res.next())
				lIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		lIdt.setMinWidth(200);
		IconedTextFieled(lId, lIdt);
		HBox h = new HBox(lId, lIdt);
		h.setAlignment(Pos.CENTER_LEFT);

		Label lName = new Label("Employee Name: ");
		lName.setPadding(new Insets(7));
		lName.setMinWidth(130);
		TextField lNamet = new TextField();
		lNamet.setMinWidth(200);
		IconedTextFieled(lName, lNamet);
		HBox h1 = new HBox(lName, lNamet);
		h1.setAlignment(Pos.CENTER_LEFT);
		
		Label dateOFBirth = new Label("Date of Birth :");
		dateOFBirth.setPadding(new Insets(7));
		dateOFBirth.setMinWidth(130);
		DatePicker dateOFBirtht = new DatePicker();
		dateOFBirtht.setEditable(false);
		dateOFBirtht.setMinWidth(200);
		IconedTextFieled(dateOFBirth, dateOFBirtht);
		HBox h2 = new HBox(dateOFBirth, dateOFBirtht);
		h2.setAlignment(Pos.CENTER_LEFT);
		
		Label lAddress = new Label("Employee Address: ");
		lAddress.setPadding(new Insets(7));
		lAddress.setMinWidth(130);
		TextField lAddresst = new TextField();
		lAddresst.setMinWidth(200);
		IconedTextFieled(lAddress, lAddresst);
		HBox h3 = new HBox(lAddress, lAddresst);
		h3.setAlignment(Pos.CENTER_LEFT);
		
		Label phNum = new Label("Phone Number :   ");
		phNum.setPadding(new Insets(7));
		phNum.setMinWidth(130);
		TextField phNumt = new TextField();
		phNumt.setMinWidth(200);
		IconedTextFieled(phNum, phNumt);
		HBox h4 = new HBox(phNum, phNumt);
		h4.setAlignment(Pos.CENTER_LEFT);
		
		Label salary = new Label("Salary :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h5 = new HBox(salary, salaryt);
		h5.setAlignment(Pos.CENTER_LEFT);
		
		Label resu = new Label("Result :        ");
		resu.setPadding(new Insets(7));
		resu.setMinWidth(130);
		TextField resut = new TextField();
		resut.setMinWidth(200);
		IconedTextFieled(resu, resut);
		HBox h6 = new HBox(resu, resut);
		h6.setAlignment(Pos.CENTER_LEFT);


		VBox v = new VBox(15, h, h1, h2, h3, h4, h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView a = new ImageView(
				new Image("G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\add.png"));
		a.setFitHeight(80);
		a.setFitWidth(80);
		Button add = new Button("Add Employee", a);
		add.setPrefSize(250, 100);
		icons(add);
		butoonEffect(add);
		add.setEffect(new DropShadow());
		
		add.setOnAction(e -> {
			try {
//				Medical_Lab_EMP2RES(int medical_EMP_ID, String medical_EMP_Name, Date medical_EMP_BD,
//						String medical_EMP_address,String phone, double medical_EMP_salary, String res)
				LocalDate value = dateOFBirtht.getValue();
				applyOnDataBase("Insert into Medical_Lab_EMP2RES(MLEID,MLEName,b_date,Address,phone,salary,result) values("
						+ lIdt.getValue() + ",'" + lNamet.getText() + "','" + value + "','" + lAddresst.getText()
						+ "','" + phNumt.getText() + "','" + salaryt.getText() + "','" + " " + "');");
				success.setContentText("Add Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in add !!");
				error.show();
			}
		});
		
		ImageView b = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(e -> {
			labButtonAction(primaryStage);
		});
		
		ImageView r = new ImageView(new Image(
				"G:\\My Drive\\UNIVERSITY\\3rd year\\2nd Semester\\COMP333\\The Project\\PHASE1&2\\refr.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button ref = new Button("Refresh", r);
		ref.setPrefSize(250, 100);
		icons(ref);
		butoonEffect(ref);
		ref.setEffect(new DropShadow());

		ref.setOnAction(e -> {
			addLabAction(primaryStage);
		});

		HBox control = new HBox(20, add, ref, back);
		control.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, control);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	private void styleTitle(Node n) {
		n.setStyle("-fx-font-size: 30;\n" + "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n"
				+ " -fx-text-fill: black;\n");
	}

	private void butoonEffect(Node b) {
		b.setOnMouseMoved(e -> {
			b.setStyle("-fx-border-radius: 25 25 25 25;\n" + "-fx-font-size: 15;\n"
					+ "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n" + " -fx-text-fill: #CE2029;\n"
					+ "-fx-background-color: #d8d9e0;\n" + "-fx-border-color: #d8d9e0;\n" + "-fx-border-width:  3.5;"
					+ "-fx-background-radius: 25 25 25 25");
		});

		b.setOnMouseExited(e -> {
			b.setStyle("-fx-border-radius: 25 25 25 25;\n" + "-fx-font-size: 15;\n"
					+ "-fx-font-family: Times New Roman;\n" + "-fx-font-weight: Bold;\n" + " -fx-text-fill: #f2f3f4;\n"
					+ "-fx-background-color: transparent;\n" + "-fx-border-color: #d8d9e0;\n"
					+ "-fx-border-width:  3.5;" + "-fx-background-radius: 25 25 25 25");
		});
	}

	private void IconedTextFieled(Node l, Node t) {
		l.setStyle("-fx-border-color: #d8d9e0;" + "-fx-font-size: 14;\n" + "-fx-border-width: 1;"
				+ "-fx-border-radius: 50;" + "-fx-font-weight: Bold;\n" + "-fx-background-color:#d8d9e0;"
				+ "-fx-background-radius: 50 0 0 50");

		t.setStyle("-fx-border-radius: 0 50 50 0;\n" + "-fx-font-size: 14;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + "-fx-background-color: #f6f6f6;\n" + "-fx-border-color: #d8d9e0;\n"
				+ "-fx-border-width:  3.5;" + "-fx-background-radius: 0 50 50 0");
	}

	private void icons(Node l) {
		l.setStyle("-fx-border-radius: 25 25 25 25;\n" + "-fx-font-size: 15;\n" + "-fx-font-family: Times New Roman;\n"
				+ "-fx-font-weight: Bold;\n" + " -fx-text-fill: #f2f3f4;\n" + "-fx-background-color: transparent;\n"
				+ "-fx-border-color: #d8d9e0;\n" + "-fx-border-width:  3.5;" + "-fx-background-radius: 25 25 25 25");
	}
	//===========================================//
	private void ActionDoc(Stage primaryStage) {
		BorderPane pane = new BorderPane();
		Image image = new Image("c:\\Users\\Lenovo\\Desktop\\All_Imgs\\blue.jpg");
		ImageView background = new ImageView(image);
		background.setFitWidth(1535);
		background.setFitHeight(800);
		pane.getChildren().add(background);

		BorderPane pane2 = new BorderPane();

		Label title = new Label("Patients");
		styleTitle(title);
		title.setPadding(new Insets(10));
		pane2.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);

		Label dId = new Label("Patient Id : ");
		dId.setPadding(new Insets(7));
		dId.setMinWidth(130);
		ComboBox<String> dIdt = new ComboBox<>();
		ResultSet res = appyQueryOnDataBase("select PID from Patients;");
		try {
			while (res.next())
				dIdt.getItems().add(res.getString(1));
		} catch (SQLException e1) {
			error.setContentText(e1.getMessage());
			error.show();
		}
		dIdt.setMinWidth(200);
		IconedTextFieled(dId, dIdt);
		HBox h7 = new HBox(dId, dIdt);
		h7.setAlignment(Pos.CENTER_LEFT);

		Label dName = new Label("Patient Name:");
		dName.setPadding(new Insets(7));
		dName.setMinWidth(130);
		TextField dNamet = new TextField();
		dNamet.setEditable(false);
		dNamet.setMinWidth(200);
		IconedTextFieled(dName, dNamet);
		HBox h1 = new HBox(dName, dNamet);
		h1.setAlignment(Pos.CENTER_LEFT);

		Label docAdress = new Label("Patient Date: ");
		docAdress.setPadding(new Insets(7));
		docAdress.setMinWidth(130);
		TextField docAdresst = new TextField();
		docAdresst.setMinWidth(200);
		IconedTextFieled(docAdress, docAdresst);
		HBox h3 = new HBox(docAdress, docAdresst);
		h3.setAlignment(Pos.CENTER_LEFT);
		Label salary = new Label("Address :         ");
		salary.setPadding(new Insets(7));
		salary.setMinWidth(130);
		TextField salaryt = new TextField();
		salaryt.setMinWidth(200);
		IconedTextFieled(salary, salaryt);
		HBox h4 = new HBox(salary, salaryt);
		h4.setAlignment(Pos.CENTER_LEFT);

		Label checkups = new Label("Checkups :");
		checkups.setPadding(new Insets(7));
		checkups.setMinWidth(130);
		ImageView del1 = new ImageView("c:\\Users\\Lenovo\\Desktop\\All_Imgs\\dele.png");
		del1.setFitHeight(20);
		del1.setFitWidth(20);
		Button del1b = new Button("",del1);
		del1b.setPrefSize(30, 30);
		icons(del1b);
		butoonEffect(del1b);
		TextArea check = new TextArea();
		check.setMaxWidth(150);
		check.setMaxHeight(90);;
		//check.setEditable(false);
		check.setMinWidth(200);
		IconedTextFieled(checkups, check);
		HBox h8 = new HBox(checkups, check,del1b);
		h8.setAlignment(Pos.CENTER_LEFT);

		Label resOfCheck = new Label("Result of checkups :        ");
		resOfCheck.setPadding(new Insets(7));
		resOfCheck.setMinWidth(130);
		TextArea resA = new TextArea();
		resA.setMaxWidth(150);
		resA.setMaxHeight(90);;
		resA.setEditable(false);
		resA.setMinWidth(200);
		IconedTextFieled(resOfCheck, resA);
		HBox h5 = new HBox(resOfCheck, resA);
		h5.setAlignment(Pos.CENTER_LEFT);

		Label drugs = new Label("Drugs :   ");
		drugs.setPadding(new Insets(7));
		drugs.setMinWidth(130);
		ImageView del2 = new ImageView("c:\\Users\\Lenovo\\Desktop\\All_Imgs\\dele.png");
		del2.setFitHeight(20);
		del2.setFitWidth(20);
		Button del2b = new Button("",del2);
		del2b.setPrefSize(30, 30);
		icons(del2b);
		butoonEffect(del2b);
		TextArea drugsT = new TextArea();
		drugsT.setMaxWidth(150);
		drugsT.setMaxHeight(90);;
		drugsT.setMinWidth(200);
		IconedTextFieled(drugs, drugsT);
		HBox h9 = new HBox(drugs, drugsT,del2b);
		h9.setAlignment(Pos.CENTER_LEFT);
		
		
		
		del1b.setOnAction(e->{
			try {
				applyOnDataBase("update patients set check_ups=\"" +" "+ "\" where PID ="+dIdt.getValue()+";");
				check.clear();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});
		
		del2b.setOnAction(e->{
			try {
				applyOnDataBase("update patients set check_ups=\"" +" "+ "\" where PID ="+dIdt.getValue()+";");
				drugsT.clear();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});

		VBox v = new VBox(15, h7, h1, h3, h8,h9,h5);
		v.setAlignment(Pos.CENTER_LEFT);
		v.setPadding(new Insets(30));

		HBox mix = new HBox(60, v);
		mix.setAlignment(Pos.CENTER);

		ImageView r = new ImageView(new Image("c:\\Users\\Lenovo\\Desktop\\All_Imgs\\save.png"));
		r.setFitHeight(80);
		r.setFitWidth(80);
		Button save = new Button("Save", r);
		save.setPrefSize(250, 100);
		icons(save);
		butoonEffect(save);
		save.setEffect(new DropShadow());
		System.out.println(ID);
		save.setOnAction(e -> {
			try {
				applyOnDataBase("update patients set check_ups=\""+check.getText()+"\" where PID ="+dIdt.getValue()+";" );
				applyOnDataBase("insert into Doc2Pa2Drug_Discribe(DID,PID,Drug_Name) values ("+ ID +"," +Integer.parseInt(dIdt.getValue())+ ",\""+drugsT.getText()+"\");");

				success.setContentText("Save Successfuly!!");
				success.show();
			} catch (Exception e2) {
				error.setContentText("Error in delete !!");
				error.show();
			}
		});
		ImageView b = new ImageView(new Image("c:\\Users\\Lenovo\\Desktop\\All_Imgs\\back.png"));
		b.setFitHeight(80);
		b.setFitWidth(80);
		Button back = new Button("Back", b);
		back.setPrefSize(250, 100);
		icons(back);
		butoonEffect(back);
		back.setEffect(new DropShadow());

		back.setOnAction(ee -> {
			doctorButtonAction(primaryStage);
		});

		dIdt.setOnAction(e -> {
			try {
				ResultSet rs = appyQueryOnDataBase("select * from Patients where PID =" + dIdt.getValue() + ";");
				rs.next();

				dNamet.setText(rs.getString(2));
				docAdresst.setText(rs.getString(3));
				check.setText(rs.getString(5));
				//specialtyt.setText(rs.getString(6));
				// dateOFBirtht.setText(rs.getString(5));
				// startWorkt.setText(rs.getString(6));
				// baseSalaryt.setText(rs.getString(7));
				// comissionRatet.setText(rs.getString(8));
				// yearlySalest.setText(rs.getString(9));

				save.setDisable(false);

			} catch (SQLException e2) {

				e2.printStackTrace();
			}
		});

		HBox h = new HBox(60, save, back);
		h.setAlignment(Pos.CENTER);

		VBox v1 = new VBox(60, mix, h);
		v1.setAlignment(Pos.CENTER);

		pane2.setCenter(v1);

		pane.setCenter(pane2);
		VBox buttons = menue(primaryStage);
		//pane.setLeft(buttons);
		Scene scene = new Scene(pane, 1535, 800);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}