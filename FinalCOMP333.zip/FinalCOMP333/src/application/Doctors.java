package application;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Doctors {
	private int dId;
	private String name;
	private int salary;
	private Date b_date;
	private String address;
	private String phone;
	private String specialty;
	public Doctors(int dId, String name, int salary, Date b_date, String address,String phone,String specialty) {
		super();
		this.dId = dId;
		this.name = name;
		this.salary = salary;
		this.b_date = b_date;
		this.address=address;
		this.phone=phone;
		this.specialty=specialty;
	}
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDateOFBirth() {
		SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
		String dateFormatted = fmt.format(b_date);
		return dateFormatted;
	}
	
	

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSpecialty() {
		return specialty;
	}
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	public void setDateOFBirth(Date dateOFBirth) {
		this.b_date = dateOFBirth;
	}
	@Override
	public String toString() {
		return "Doctors [dId=" + dId + ", name=" + name + ", salary=" + salary + ", b_date=" + b_date + ", address="
				+ address + ", phone=" + phone + ", specialty=" + specialty + "]";
	}
	

}
